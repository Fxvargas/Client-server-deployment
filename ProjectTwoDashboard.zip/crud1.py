from pymongo import MongoClient
from bson.objectid import ObjectId
from pprint import pprint

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """
    
    def __init__(self, username, password):
        #Initializing the MongoClient. This helps to access the MondoDB databases and collections.
        self.client = MongoClient('mongodb://%s:%s@localhost:52453/?authMechanism=DEFAULT&authSource=AAC' % (username, password))
        self.database = self.client['AAC']
        
#Complete this create method to implement the C in CRUD.
    def createDoc(self, data): #This function will insert the new document into the DB.
        if data is not None:
            createResult = self.database.animals.insert(data) #data should be dictionary
            print(createResult) #Print the result.
            
            return True
        else:
            raise Exception("Nothing to save because data parameter is empty.")
            return False
            
#Create a method to implement the R in CRUD.
    def readDoc(self, data): #This function will search for a document matching the key value pairs passed through "data".
        if data is not None:
            results = self.database.animals.find(data, {"_id" : False}) #Search for document using the key value pairs passed and store in "results".
#            for doc2 in results: #Iterate through "results" to display its contents.
#               pprint(doc2)
#            print(results)
# 
            return results
        else:
            raise Exception("Nothing to save because data parameter is empty.")
            return False